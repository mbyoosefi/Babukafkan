# Tools

| File | Purpose | Writes? |
|---|---|---|
| `babuk_recover.py` | Main interactive wizard — start here | only after `y` |
| `deep_probe.py` | Read-only forensic profile of one disk | never |
| `rebuild_mbr.py` | Rebuild a destroyed MBR partition table | only with `--apply` |
| `gpt_info.py` | Print the GPT table from the end-of-disk backup | never |
| `babuk_mft.py` | Read `$MFT`, list and extract files without mounting | only on `extract` |
| `refs_veeam.py` | ReFS / Veeam repository recovery | only with `--apply` |

All are standard-library only. All run on the ESXi shell.
`babuk_mft.py` needs Python 3.6+; the rest run on 3.5+.
